package Controller;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

/**
 * 重试模板类
 */
public abstract class RetryTemplate {

    private static final int DEFAULT_RETRY_TIME=1;
    private int retryTime =DEFAULT_RETRY_TIME;
    //重试的睡眠时间
    private int sleepTime=0;

    public int getSleepTime(){
        return sleepTime;
    }

    public RetryTemplate setSleepTime(int sleepTime)  {
        if(sleepTime<0){
            throw new IllegalArgumentException("休眠时间应大于等于0！");
        }
        this.sleepTime=sleepTime;
        return this;
    }

    public int getRetryTime(){
        return retryTime;
    }

    public RetryTemplate setRetryTime(int retryTime){
        if(retryTime<=0){
            throw new IllegalArgumentException("重试次数应该大于等于0！");
        }
        this.retryTime=retryTime;
        return this;
    }

    /**
     * 重试的业务执行代码
     * 失败时抛出一个异常
     * @return
     * @throws Exception
     */
    protected abstract Object doBiz() throws Exception;

    public Object execute() throws InterruptedException{
        for(int i=0;i<retryTime;i++){
            try {
                System.out.println("第"+i+"次执行重试");
                return doBiz();
            } catch (Exception e) {
                System.out.println("业务执行异常："+e.getMessage());
                Thread.sleep(sleepTime);
            }
        }
        return null;
    }

    public Object submit(ExecutorService executorService){
        if(executorService==null){
            throw new IllegalArgumentException("please choose executorService");
        }
        return executorService.submit((Callable)() ->execute());
    }

}
