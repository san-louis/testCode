package Controller;

import com.alibaba.fastjson.JSONObject;
import lombok.SneakyThrows;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * louis 2022-02-21
 * 测试主函数
 */
public class DemoApplicaition {

    public static OkHttpClient getOkHttpClient() {
        return new OkHttpClient().newBuilder().build();

    }

    public AtomicInteger inc = new AtomicInteger(0);

    public void increase() {
        inc.getAndIncrement();
    }

    public void decrement() {
        inc.getAndDecrement();
    }

    /**
     * 运行demo方法
     * @param province
     * @param city
     * @param county
     * @throws IOException
     * @throws InterruptedException
     */
    public void runDemo(String province, String city, String county) throws IOException, InterruptedException {
        if(inc.get() > 0){ // 计数器中的值要大于0才能启动线程
            System.out.println(getTemperature(province,city,county).get());
        }else {
            System.out.println("线程尚未开启");
            Thread.sleep(10);
        }
    }

    // 计数器功能，规则是一秒中累加100，超过100不累加
    public void runCounter(){
        while(inc.get()<100){
            try {
                Thread.sleep(10);//休眠10毫秒，即一秒钟能执行100次
                increase();
                System.out.println("当前计数器中的数值为："+inc.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    @SneakyThrows
    public Optional<String> getTemperature(String province, String city, String county) {
        decrement();
        OkHttpClient okHttpClient = getOkHttpClient();
        //获取省份code
        String provinceCodeUrl=Constant.PROVINCE_CODE_URL;
        String provinceCode =getKeyOfJsonObj(okHttpClient,provinceCodeUrl,province,Constant.PROVINCE);
        System.out.println("省份代码："+provinceCode);

        //获取城市code
        String cityCodeUrl =String.format(Constant.CITY_CODE_URL,provinceCode);
        String cityCode =getKeyOfJsonObj(okHttpClient,cityCodeUrl,city,Constant.CITY);
        System.out.println("城市代码："+cityCode);

        //获取县code
        String countryCodeUrl =String.format(Constant.COUNTRY_CODE_URL,provinceCode,cityCode);
        String countryCode =getKeyOfJsonObj(okHttpClient,countryCodeUrl,county,Constant.COUNTRY);
        System.out.println("县代码："+cityCode);

        //获取天气信息
        String weatherCodeUrl =String.format(Constant.WEATHER_CODE_URL,provinceCode,cityCode,countryCode);

        try {
            return getWeather(okHttpClient,weatherCodeUrl);

        } catch (Exception e) {
            //天气API经常出现异常，设置重试机制
            Object ans = new RetryTemplate() {
                @Override
                protected Object doBiz() throws Exception {
                    return getWeather(okHttpClient,weatherCodeUrl);
                }
            }.setRetryTime(5).setSleepTime(10).execute(); //设置重试次数，休眠时间
        }
        throw new RuntimeException("请检查省、市、县的信息是否输入正确！");
    }

    /**
     * 获取json对象key值公共方法  获取各个接口的CODE
     * @param okHttpClient
     * @param url
     * @param value
     * @return
     */
    private String getKeyOfJsonObj(OkHttpClient okHttpClient,String url,String value,String type){
        String key="";
        //构建request请求
        Request request = new Request.Builder().url(url).get().build();

        try {
            Response response = okHttpClient.newCall(request).execute();
            String resultStr  = response.body().string();
            System.out.println("响应报文为："+resultStr);
            if(type.equals(Constant.WEATHER)&&"".equals(value)){
                return resultStr;
            }

            JSONObject jsonObj =JSONObject.parseObject(resultStr);

            //遍历JSON对象
            Iterator iter =jsonObj.entrySet().iterator();
            List<String> list = new ArrayList<String>();
            while (iter.hasNext()){
                Map.Entry entry = (Map.Entry) iter.next();
                list.add(entry.getValue().toString());
                if(entry.getValue().toString().equals(value)){
                    key=entry.getKey().toString();
                }
            }
            //如果返回的value集合中包含次结果则返回key值
            if(list.contains(value)){
                //返回code
                return key;
            }else{
                throw new RuntimeException(type+"不存在:"+value);
            }

        } catch (IOException e) {
            System.out.println("运行时出现异常："+e.getMessage());
        }
        return key;
    }

    /**
     * 获取天气信息
     * @param okHttpClient
     * @param weatherCodeUrl
     * @return
     */
    private Optional<String> getWeather(OkHttpClient okHttpClient, String weatherCodeUrl) {

        String jsonResult=getKeyOfJsonObj(okHttpClient,weatherCodeUrl,"",Constant.WEATHER);
        System.out.println("天气的响应报文字符串："+jsonResult);

        JSONObject jsonObj =JSONObject.parseObject(jsonResult);
        //如果正确获取到了接口的返回结果
        if(jsonResult.indexOf("weatherinfo")!=-1){
            JSONObject weatherJsonObj=jsonObj.getJSONObject("weatherinfo");
            String temperature =weatherJsonObj.getString("temp");
            Optional<String> optional =Optional.ofNullable(temperature);
            return optional;
        }
        throw new RuntimeException("请检查省、市、县的信息是否输入正确！");
    }
}

