package Controller;

/**
 * 常量类
 * 用于枚举
 */
public class Constant {

    public static String PROVINCE_CODE_URL = "http://www.weather.com.cn/data/city3jdata/china.html";//获取中国省代码
    public static String CITY_CODE_URL= "http://www.weather.com.cn/data/city3jdata/provshi/%s.html";//获取城市代码
    public static String COUNTRY_CODE_URL = "http://www.weather.com.cn/data/city3jdata/station/%s%s.html";//获取县代码
    public static String WEATHER_CODE_URL= "http://www.weather.com.cn/data/sk/%s%s%s.html";//获取县的天气代码
    public static String PROVINCE="省";
    public static String CITY="城市";
    public static String COUNTRY="县";
    public static String WEATHER="天气";

}
