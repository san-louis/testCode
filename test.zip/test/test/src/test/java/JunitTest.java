import Controller.DemoApplicaition;
import org.junit.Test;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 单元测试类
 */
public class JunitTest {
    @Test
    public void test()throws InterruptedException {
        DemoApplicaition da = new DemoApplicaition();
        new Thread(() -> {
            da.runCounter();// 开启线程去计数
        }).start();
        Thread.sleep(2000);// 休眠两秒 计数加满100
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(100);
        for (int i = 0;i < 100;i++){
            fixedThreadPool.execute(() -> {
                try {
                    da.runDemo("江苏","扬州","扬州");
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            });
        }
        Thread.sleep(5000);// 休眠5S，防止主线程提前结束
    }
}